
import { NextRequest, NextResponse } from 'next/server'
import { serverClient } from '@/lib/supabase'

function haversineKm(lat1:number, lon1:number, lat2:number, lon2:number) {
  const R = 6371
  const toRad = (d:number)=> d*Math.PI/180
  const dLat = toRad(lat2-lat1), dLon = toRad(lon2-lon1)
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2
  return 2*R*Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { service_id, vehicle_class, lat, lon, operator_lat, operator_lon, surcharges=[] } = body
  if (!service_id || !vehicle_class || typeof lat!=='number' || typeof lon!=='number') {
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
  }
  const supa = serverClient()
  const { data: svc } = await supa.from('services').select('id, base_price_cents, base_duration_min').eq('id', service_id).single()
  if (!svc) return NextResponse.json({ error: 'Service not found' }, { status: 404 })
  const { data: set } = await supa.from('settings').select('value').eq('key','pricing').maybeSingle()
  const params:any = set?.value ?? { base_radius_km: 5, per_km_cents: 60, buffer_min: 15 }

  const opLat = typeof operator_lat === 'number' ? operator_lat : 44.841225
  const opLon = typeof operator_lon === 'number' ? operator_lon : -0.580036
  const distanceKm = haversineKm(opLat, opLon, lat, lon)

  let extra = 0; let percent = 0
  if (Array.isArray(surcharges) && surcharges.length > 0) {
    if (typeof surcharges[0] === 'string') {
      const { data: rows } = await supa.from('surcharges').select('id, price_cents, percent').in('id', surcharges as string[])
      for (const r of rows || []) { extra += r.price_cents || 0; percent += r.percent || 0 }
    } else {
      for (const s of surcharges) { extra += s.price_cents || 0; percent += s.percent || 0 }
    }
  }

  const classMult: Record<string, number> = { city:1, compact:1.05, berline:1.15, suv:1.30, van:1.45, moto:0.8 }
  const basePrice = svc.base_price_cents
  const kmFee = Math.max(0, distanceKm - params.base_radius_km) * params.per_km_cents
  let subtotal = Math.round(basePrice * (classMult[vehicle_class] ?? 1) + kmFee + extra)
  const total = Math.round(subtotal * (1 + percent/100))
  const minutes = svc.base_duration_min + params.buffer_min

  return NextResponse.json({ distance_km: Math.round(distanceKm*10)/10, price_cents: total, minutes })
}
