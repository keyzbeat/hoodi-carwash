
import { NextRequest, NextResponse } from 'next/server'
import { serverClient } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  const supa = serverClient()
  const { booking_id, title, body } = await req.json()
  if (!booking_id) return NextResponse.json({ error: 'Missing booking_id' }, { status: 400 })
  const { data: booking } = await supa.from('bookings').select('user_id, start_at').eq('id', booking_id).single()
  if (!booking) return NextResponse.json({ ok: true })

  const { data: tokens } = await supa.from('expo_push_tokens').select('token').eq('user_id', booking.user_id)
  if (!tokens || tokens.length === 0) return NextResponse.json({ ok: true, msg: 'no tokens' })

  const messages = tokens.map(t => ({ to: t.token, sound: 'default', title: title || 'Réservation confirmée', body: body || 'Merci. À bientôt!' }))
  // Send to Expo push API (no token required for basic usage)
  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(messages)
  })
  return NextResponse.json({ ok: true })
}
