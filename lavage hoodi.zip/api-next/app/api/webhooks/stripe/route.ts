
import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { serverClient } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature')
  const secret = process.env.STRIPE_WEBHOOK_SECRET
  if (!sig || !secret) return NextResponse.json({ ok: true })
  const buf = Buffer.from(await req.arrayBuffer())
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2024-06-20' })
  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(buf, sig, secret)
  } catch (err:any) {
    return NextResponse.json({ error: `Webhook Error: ${err.message}` }, { status: 400 })
  }

  const supa = serverClient()
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session
    const booking_id = session.metadata?.booking_id
    if (booking_id) {
      await supa.from('payments').insert([{
        booking_id, provider: 'stripe', amount_cents: session.amount_total || 0, status: 'paid', external_id: session.id
      }])
      await supa.from('bookings').update({ status: 'confirmed' }).eq('id', booking_id)
    }
  }
  return NextResponse.json({ received: true })
}
