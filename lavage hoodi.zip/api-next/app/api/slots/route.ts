
import { NextRequest, NextResponse } from 'next/server'
import { serverClient } from '@/lib/supabase'
export async function GET(req: NextRequest) {
  const url = new URL(req.url)
  const from = url.searchParams.get('from')
  const to = url.searchParams.get('to')

  const supa = serverClient()
  let q = supa.from('slots').select('*').eq('is_booked', false)
  if (from) q = q.gte('start_at', from)
  if (to) q = q.lte('end_at', to)
  const { data, error } = await q
  if (error) return NextResponse.json({ error: error.message }, { status: 400 })
  return NextResponse.json({ slots: data })
}
