
import { NextRequest, NextResponse } from 'next/server'
import { serverClient } from '@/lib/supabase'
export async function GET(req: NextRequest) {
  const token = req.headers.get('authorization')?.replace('Bearer ', '')
  if (!token) return NextResponse.json({ user: null }, { status: 200 })
  const supa = serverClient()
  const { data, error } = await supa.auth.getUser(token)
  if (error) return NextResponse.json({ user: null, error: error.message }, { status: 200 })
  return NextResponse.json({ user: data.user })
}
