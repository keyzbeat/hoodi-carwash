
import { NextRequest, NextResponse } from 'next/server'
import { serverClient } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  const body = await req.json()
  const supa = serverClient()
  const token = req.headers.get('authorization')?.replace('Bearer ', '')
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { data: auth, error: authErr } = await supa.auth.getUser(token)
  if (authErr || !auth?.user) return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
  const user_id = auth.user.id

  const { operator_id, vehicle_id, service_id, address, latitude, longitude, start_at, end_at, price_cents, notes, surcharges=[] } = body
  if (!service_id || !start_at || !end_at || !price_cents || !address) {
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
  }
  const { data: booking, error } = await supa
    .from('bookings')
    .insert([{ user_id, operator_id, vehicle_id, service_id, address, latitude, longitude, start_at, end_at, price_cents, status: 'pending', notes }])
    .select('*').single()
  if (error || !booking) return NextResponse.json({ error: error?.message || 'DB error' }, { status: 400 })

  if (Array.isArray(surcharges) && surcharges.length > 0) {
    const rows = surcharges.map((s:any) => ({ booking_id: booking.id, surcharge_id: s.id || s }))
    await supa.from('booking_surcharges').insert(rows)
  }
  return NextResponse.json({ booking }, { status: 201 })
}
