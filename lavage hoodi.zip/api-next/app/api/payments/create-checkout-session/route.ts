
import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { serverClient } from '@/lib/supabase'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2024-06-20' })

export async function POST(req: NextRequest) {
  if (!process.env.STRIPE_SECRET_KEY) return NextResponse.json({ error: 'Stripe not configured' }, { status: 400 })
  const { booking_id, amount_cents, success_url, cancel_url } = await req.json()
  if (!booking_id || !amount_cents) return NextResponse.json({ error: 'Missing fields' }, { status: 400 })

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'payment',
    line_items: [{
      price_data: { currency: 'eur', product_data: { name: 'Acompte LavageAuto' }, unit_amount: amount_cents },
      quantity: 1
    }],
    success_url: success_url || 'https://example.com/success?session_id={CHECKOUT_SESSION_ID}',
    cancel_url: cancel_url || 'https://example.com/cancel',
    metadata: { booking_id }
  })
  return NextResponse.json({ url: session.url })
}
