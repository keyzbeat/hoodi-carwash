
import { NextResponse } from 'next/server'
import { serverClient } from '@/lib/supabase'
export async function GET() {
  const supa = serverClient()
  const { data, error } = await supa.from('services').select('*').eq('active', true).order('title')
  if (error) return NextResponse.json({ error: error.message }, { status: 400 })
  return NextResponse.json({ services: data })
}
